SELECT * FROM amazon_sales.amazon;

select * from amazon;
-- select *,case 
-- when time >= 04 and time <12 then "Morning"
-- when time > 12 and time <= 17 then "Afternoon"
-- else "Night"
-- end as timeofday 
-- from amazon;  

select * from amazon;

alter table amazon add column month_name text;


update amazon set time_of_day = case 
when time >= 04 and time <12 then "Morning"
when time > 12 and time <= 17 then "Afternoon"
else "Night"
end; 

update amazon set dayname = dayname(date);

update amazon set month_name = monthname(date);




-- Q1  count of distinct cities in data set 

select DISTINCT(city),COUNT(city) as order_count from amazon
GROUP BY city;

-- Q2 For each branch, what is the corresponding city? 

select city,branch from amazon 
group by city,branch;

-- Q3 What is the count of distinct product lines in the dataset? 
select * from amazon;
select product_line, count(product_line) as count_of_product_line from amazon
group by product_line;

-- Q4 Which payment method occurs most frequently?

select DISTINCT payment, count(payment) as payment_mode_count from amazon
GROUP BY payment limit 1; 

-- Q5 Which product line has the highest sales? 

select product_line, sum(Quantity) as total_order_count from amazon        -- as the 8th question was dealing with revenue so 
group by Product_line order by sum(Quantity)  desc;                        -- i took the quantity as sales perameter here in this question.




-- Q6 How much revenue is generated each month? 

select year(date) as year ,monthname(date) as month_name, 
round(sum(total),2) as total_sales   from amazon
group by year(date), monthname(date),month(date)        
order by month(date);                                 -- with this query i saw a dip in revenue in the month of februrary                                               
													  -- but there is recovery in the next month


-- Q7 In which month did the cost of goods sold reach its peak?

select month_name, round(sum(cogs),2) as total_cogs from amazon
group by month_name
order by total_cogs desc
limit 1;


-- Q8 Which product line generated the highest revenue?

SELECT Product_line, round(sum(total),2) as revenue_by_productline  from amazon
group by Product_line
order by sum(total) desc                              -- every product_line is doing more or less greate revenue wise but Health and beauty product need some extra work
;

-- Q9 In which city was the highest revenue recorded?

SELECT city, sum(total) as total_by_productline from amazon     
group by city
order by sum(total) desc
limit 1;

-- Q10 Which product line incurred the highest Value Added Tax? 

ALTER TABLE amazon CHANGE COLUMN `tax_5%` `vat_tax` double;

select Product_line, round(sum(vat_tax),2) as total_by_productline from amazon
group by Product_line
order by sum(vat_tax) desc
limit 1;

-- Q11 For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."

create view table2 as select Product_line, sum(total) as total_by_product from amazon 
group by Product_line; 

select *,
case when total_by_product > (select avg(total_by_product) from table2) then 'GOOD'
else "BAD"
end as 'STATUS'
from table2;

-- Q12 Identify the branch that exceeded the average number of products sold. 


create view avg_product_sold as select avg(quantity) from amazon;

select * from amazon WHERE Quantity > (select * from avg_product_sold);


-- Q13 Which product line is most frequently associated with each gender? 

Select product_line, sum(case when gender = 'male' then 1 else 0 end) as Male,
sum(case when gender = 'female' then 1 else 0 end) as Female
From amazon group by
product_line;


-- Q14 Calculate the average rating for each product line. 

select product_line, round(avg(rating),1) as avg_rating from amazon
group by (product_line);

-- Q15 Count the sales occurrences for each time of day on every weekday. 

select dayname, count(*) as Freq_of_cust from amazon 
where dayname not in ('saturday','sunday')
group by dayname;

-- Q16 Identify the customer type contributing the highest revenue.

select customer_type, round(sum(total),2) total from amazon 
group by Customer_type limit 1;

-- Q17 Determine the city with the highest VAT percentage. 


select city, concat(round((sum(vat_tax)/(SELECT sum(vat_tax) from amazon))*100,2),'%')as tax_per_city from amazon 
group by city  
order by tax_per_city desc
limit 1;

-- Q18 Identify the customer type with the highest VAT payments.

select customer_type, count(*) as freq ,round(sum(vat_tax),2) as total from amazon 
group by Customer_type
order by freq desc
limit 1;

-- Q19 What is the count of distinct customer types in the dataset?

select Customer_type, count(customer_type) from amazon	
group by Customer_type;


-- Q20 What is the count of distinct payment methods in the dataset?

select payment, count(*) as pay_mode_count from amazon 
group by payment
order by pay_mode_count desc;

-- Q21 Which customer type occurs most frequently?

select customer_type, count(*) as count from amazon
group by customer_type 
order by count desc
limit 1;

-- Q22 Identify the customer type with the highest purchase frequency.
select customer_type, count(*) as count from amazon
group by customer_type 
order by count desc
limit 1;

-- Q23 Determine the predominant gender among customers

select gender, count(gender) as count from amazon 
group by gender;

-- Q24 Examine the distribution of genders within each branch. 

select branch,gender,count(gender) as count from amazon
group by branch, gender
order by branch asc;

-- Q25 Identify the time of day when customers provide the most ratings. 


select time_of_day, count(rating) as total_count,round(sum(rating),2) as sum_of_rat,round(sum(rating)/count(rating),1) as avg_rating from amazon
group by time_of_day
order by total_count desc          
limit 1;        -- in after noon the customers are being more generous while giving ratings.




-- Q26 Determine the time of day with the highest customer ratings for each branch.

select * from amazon;

select branch,time_of_day, max(rating) from amazon 
group by branch,time_of_day
order by branch;

-- Q27 Identify the day of the week with the highest average ratings.

select dayname, round(avg(rating),1) as avg_rating from amazon 
group by dayname
order by avg_rating desc
limit 1;

-- Q28 Determine the day of the week with the highest average ratings for each branch. 

create view top_rating1 as select branch,dayname, avg(rating) as avg_rating,
row_number() over(partition by branch order by avg(rating) desc) as Max_rank from amazon 
GROUP BY branch, dayname;

select branch, dayname, round(avg_rating,2)
from top_rating1
where Max_rank = 1;


